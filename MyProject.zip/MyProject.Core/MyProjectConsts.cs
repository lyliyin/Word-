﻿namespace MyProject
{
    public class MyProjectConsts
    {
        public const string LocalizationSourceName = "MyProject";
    }
}